package com.capgemini.capstore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.Coupon;
import com.capgemini.capstore.exceptions.CouponNotFoundException;
import com.capgemini.capstore.service.CapStoreServiceI;

@RestController
	@RequestMapping("/coupon")
	
	public class CustomerController {
		@Autowired
		CapStoreServiceI service;

		@PostMapping("/create")
		public Coupon createcoupon( @RequestBody Coupon coupon)   {
			return service.createcoupon(coupon);
		}
		
		@GetMapping("/showDetails/{couponId}")
		public Coupon couponDetails(@PathVariable Long couponId) throws CouponNotFoundException {
			return service.couponDetails(couponId);
		}
		
	}


