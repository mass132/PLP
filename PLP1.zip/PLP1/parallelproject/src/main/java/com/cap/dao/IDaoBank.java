package com.cap.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cap.entity.BankEntity;

@Repository
public interface IDaoBank extends JpaRepository<BankEntity, Long>{

}
