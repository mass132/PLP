import { Component, OnInit } from '@angular/core';
import { Customer } from 'src/Models/Customer';
import { Transactions } from 'src/Models/Transactions';
import { Router } from '@angular/router';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {

  isLogin:boolean=true;
  customers:Customer[]=[];
  createdTransaction:Transactions;
  router:Router;
  
  service:ServiceService;
  constructor(service:ServiceService,router:Router) { 
    this.service=service;
    this.isLogin=this.service.isLogin;
    this.router=router;
  }

  withdrawAmount(data:any){
    let caccount_first=data.caccount;
    let cbalance=data.cbalance;
    var ttype:string;
    ttype="Withdraw Amount"

    this.service.withdrawBalance(caccount_first,cbalance);
    
    this.createdTransaction=new Transactions("123",data.caccount,"",data.cbalance,ttype);
    this.service.addTransaction(this.createdTransaction)
    this.router.navigate(['view']);
  }

  ngOnInit() {
    this.customers=this.service.getCustomers();
  }

}
