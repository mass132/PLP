package com.java.parallelservices;
import java.util.List;

import com.java.parallelBean.Bean;
import com.java.parallelDAO.DaoClass;
public class Service {
	DaoClass d=new DaoClass();
	public long service(Bean b) {
	    long accNum1=d.service1(b);
    return accNum1;
}
public long showbalance(long bacc,String password1) {
	long bal=d.showbalance(bacc,password1);
	return  bal;	
}
public  long deposit(long account2, String password2, long dep1) {
	long d1= d.deposit1(account2,password2,dep1);
	//System.out.println(d1);
	return  d1;	
}
public long withdraw(long account3, String password3, long wit1) 
{
long w1=d.withdraw(account3, password3, wit1);
	return w1;
}
public long fund(long account4,  long account5,String password4,long f1) 
{
long f=d.fund(account4, account5, password4, f1);
	return f;
}

public boolean validation(long account2, String password2)
{
	boolean d11=d.validation(account2,password2);
	return d11;
}
public boolean validation1(long account4, String password4, long account5) {
	boolean d11=d.validation1(account4,password4,account5);
	return d11;
}
public List trans() {
	List aq2=d.trans();
	return aq2;
}
}
