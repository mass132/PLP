package com.capgemini.capstore.service;

import javax.validation.Valid;

import com.capgemini.capstore.beans.Coupon;
import com.capgemini.capstore.exceptions.CouponNotFoundException;

public interface CapStoreServiceI {

	Coupon createcoupon( Coupon coupon) ;

	Coupon couponDetails(Long couponId)throws CouponNotFoundException;


}
