package com.capgemini.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Coupon;
import com.capgemini.capstore.dao.IDAO;
import com.capgemini.capstore.exceptions.CouponNotFoundException;

@Service
public class CapStoreService implements CapStoreServiceI {

	@Autowired
	IDAO Dao;
	@Override
	public Coupon createcoupon(Coupon coupon)  {		
		Dao.save(coupon);
		return Dao.save(coupon);
			}

	@Override
	public Coupon couponDetails(Long couponId) throws CouponNotFoundException{
			if (!Dao.findById(couponId).isPresent())
			{
				throw new CouponNotFoundException("Invalid coupon number!!!");
			}
			else 
			{
				return Dao.findById(couponId).get();
			}

		}

	}

	